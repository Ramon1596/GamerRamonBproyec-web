// variables
var dia_Semana = new Array("Domingo","Lunes","Martes","Miercoles","Domingo","Sabado");


//funciones 
function calcularDiaSemana(){
	var fecha = new Date ();
	var numero_dia = fecha.getDay();

	var dia = dia_Semana[numero_dia];

	document.getElementById("item_day").innerHTML = dia;

}


window.onload = calcularDiaSemana();